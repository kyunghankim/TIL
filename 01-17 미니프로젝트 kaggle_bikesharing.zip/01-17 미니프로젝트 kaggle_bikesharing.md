```python
1. bike data 불러오기
- 각 데이터 확인(shape, info, ...)
2. 중복 확인
- 훈련 데이터, 테스트 데이터 중복 값 있는지 확인
- 훈련 데이터, 테스트 데이터 null 값 확인
3. datetime에서 년,월,일,시,분,초를 추출하여 각각의 column으로 구성
ex) df['year]=df['datetime'].dt.year
-년,월,일,시 에 따른 평균 대여량 구하기
=> 분석 결과 reporting (ex. 여름에 대여량이 많다)
4. 근무일 유무/요일/시즌/날씨에 따른 시간대별 자전거 대여량 구하기
5. 연도별 월별 자전거 대여량 구하기
```


```python
6. 아웃라이어제거
정상범위 데이터 : count열값-count열값평균 < 3*(count.std)
7. 시즌컬럼 원핫 인코딩
-season_1, ... season_4
 0 0 0 1
...
-기존 데이터 프레임에 원핫인코딩 결과열 결합
8.데이터 보정
-풍속 등 각 필드에 0으로 저장되어 있는 값을 근사값으로 보정
9. 바이크 대여수 예상되는 값 출력 (knn기반)
-조건문 기반 작성
10. 제출
```


```python
import pandas as pd
import numpy as np
```


```python
trainbike=pd.read_csv("trainbike.csv")
testbike=pd.read_csv("testbike.csv")
```


```python
trainbike.info()   <- datatime이 object로 나옴, 문자로 나오는것
```


      File "<ipython-input-166-3019906fcd65>", line 1
        trainbike.info()   <- datatime이 object로 나옴, 문자로 나오는것
                                              ^
    SyntaxError: invalid syntax
    



```python
trainbike=pd.read_csv("trainbike.csv",parse_dates=["datetime"]) <-datatime64 타입으로 지정해줌
trainbike.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10886 entries, 0 to 10885
    Data columns (total 12 columns):
    datetime      10886 non-null datetime64[ns]
    season        10886 non-null int64
    holiday       10886 non-null int64
    workingday    10886 non-null int64
    weather       10886 non-null int64
    temp          10886 non-null float64
    atemp         10886 non-null float64
    humidity      10886 non-null int64
    windspeed     10886 non-null float64
    casual        10886 non-null int64
    registered    10886 non-null int64
    count         10886 non-null int64
    dtypes: datetime64[ns](1), float64(3), int64(8)
    memory usage: 1020.7 KB
    


```python
trainbike['datetime'].dt.year
```




    0        2011
    1        2011
    2        2011
    3        2011
    4        2011
             ... 
    10881    2012
    10882    2012
    10883    2012
    10884    2012
    10885    2012
    Name: datetime, Length: 10886, dtype: int64




```python
trainbike['datetime'].dt.month     <- datatime64에서 연/월/일로 따로 뽑을 수 있음
```




    0         1
    1         1
    2         1
    3         1
    4         1
             ..
    10881    12
    10882    12
    10883    12
    10884    12
    10885    12
    Name: datetime, Length: 10886, dtype: int64




```python
trainbike['datetime'].dt.day
#trainbike['datetime'].dt.hour
```




    0         1
    1         1
    2         1
    3         1
    4         1
             ..
    10881    19
    10882    19
    10883    19
    10884    19
    10885    19
    Name: datetime, Length: 10886, dtype: int64




```python
trainbike['datetime'].dt.dayofweek       <- 요일에 대한 정보(월:0,일:6)
```




    0        5
    1        5
    2        5
    3        5
    4        5
            ..
    10881    2
    10882    2
    10883    2
    10884    2
    10885    2
    Name: datetime, Length: 10886, dtype: int64




```python
import datetime
today="2020-01-17"
datetime.datetime.strptime(today,"%Y-%m-%d").date()     <-datetime객체로 바꾸어줌
```


      File "<ipython-input-4-78dd2da786f8>", line 3
        datetime.datetime.strptime(today,"%Y-%m-%d").date()     <-datetime객체로 바꾸어줌
                                                                                 ^
    SyntaxError: invalid syntax
    



```python
import datetime
today="20200117"
datetime.datetime.strptime(today,"%Y%m%d").date() 
```




    datetime.date(2020, 1, 17)




```python
datetime.datetime.today()
datetime.datetime.today().strftime("%Y")   <- 년도만 추출하기
```




    '2020'




```python
datetime.datetime.today().strftime("%m")
```




    '01'




```python
today="2020-01-17 10:18:20.123"
datetime.datetime.strptime(today,"%Y-%m-%d %H:%M:%S.%f")
```




    datetime.datetime(2020, 1, 17, 10, 18, 20, 123000)




```python
==========================수업내용===============================
```


```python
*실습:
```


```python
testbike.isnull().sum()
```




    datetime      0
    season        0
    holiday       0
    workingday    0
    weather       0
    temp          0
    atemp         0
    humidity      0
    windspeed     0
    dtype: int64




```python
trainbike.isnull().sum()
```




    datetime      0
    season        0
    holiday       0
    workingday    0
    weather       0
    temp          0
    atemp         0
    humidity      0
    windspeed     0
    casual        0
    registered    0
    count         0
    dtype: int64




```python
tr1=trainbike.copy()
te1=testbike.copy()
```


```python
tr1.duplicated()
te1.duplicated()
```




    0       False
    1       False
    2       False
    3       False
    4       False
            ...  
    6488    False
    6489    False
    6490    False
    6491    False
    6492    False
    Length: 6493, dtype: bool




```python
print(tr1['datetime'])
print("="*60)
print(te1['datetime'])              <-train,test 날짜 확인해보기
```

    0       2011-01-01 00:00:00
    1       2011-01-01 01:00:00
    2       2011-01-01 02:00:00
    3       2011-01-01 03:00:00
    4       2011-01-01 04:00:00
                    ...        
    10881   2012-12-19 19:00:00
    10882   2012-12-19 20:00:00
    10883   2012-12-19 21:00:00
    10884   2012-12-19 22:00:00
    10885   2012-12-19 23:00:00
    Name: datetime, Length: 10886, dtype: datetime64[ns]
    ============================================================
    0       2011-01-20 00:00:00
    1       2011-01-20 01:00:00
    2       2011-01-20 02:00:00
    3       2011-01-20 03:00:00
    4       2011-01-20 04:00:00
                   ...         
    6488    2012-12-31 19:00:00
    6489    2012-12-31 20:00:00
    6490    2012-12-31 21:00:00
    6491    2012-12-31 22:00:00
    6492    2012-12-31 23:00:00
    Name: datetime, Length: 6493, dtype: object
    


```python
import datetime as dt
```


```python
#te1['datetime'].dt.year
tr1['datetime'].dt.year
#te1['datetime'].dt.year
tr1['datetime'].dt.month
tr1['datetime'].dt.day
tr1['datetime'].dt.hour
tr1['datetime'].dt.minute
tr1['datetime'].dt.second

```




    0        0
    1        0
    2        0
    3        0
    4        0
            ..
    10881    0
    10882    0
    10883    0
    10884    0
    10885    0
    Name: datetime, Length: 10886, dtype: int64




```python
3. datetime에서 년/월/일/시/분/초 추출 후 각 column으로 구성
```


```python
tr1['year']=tr1['datetime'].dt.year
tr1['month']=tr1['datetime'].dt.month
tr1['hour']=tr1['datetime'].dt.hour
tr1['minute']=tr1['datetime'].dt.minute
tr1['second']=tr1['datetime'].dt.second
print(tr1)
```

                     datetime  season  holiday  workingday  weather   temp  \
    0     2011-01-01 00:00:00       1        0           0        1   9.84   
    1     2011-01-01 01:00:00       1        0           0        1   9.02   
    2     2011-01-01 02:00:00       1        0           0        1   9.02   
    3     2011-01-01 03:00:00       1        0           0        1   9.84   
    4     2011-01-01 04:00:00       1        0           0        1   9.84   
    ...                   ...     ...      ...         ...      ...    ...   
    10881 2012-12-19 19:00:00       4        0           1        1  15.58   
    10882 2012-12-19 20:00:00       4        0           1        1  14.76   
    10883 2012-12-19 21:00:00       4        0           1        1  13.94   
    10884 2012-12-19 22:00:00       4        0           1        1  13.94   
    10885 2012-12-19 23:00:00       4        0           1        1  13.12   
    
            atemp  humidity  windspeed  casual  registered  count  year  month  \
    0      14.395        81     0.0000       3          13     16  2011      1   
    1      13.635        80     0.0000       8          32     40  2011      1   
    2      13.635        80     0.0000       5          27     32  2011      1   
    3      14.395        75     0.0000       3          10     13  2011      1   
    4      14.395        75     0.0000       0           1      1  2011      1   
    ...       ...       ...        ...     ...         ...    ...   ...    ...   
    10881  19.695        50    26.0027       7         329    336  2012     12   
    10882  17.425        57    15.0013      10         231    241  2012     12   
    10883  15.910        61    15.0013       4         164    168  2012     12   
    10884  17.425        61     6.0032      12         117    129  2012     12   
    10885  16.665        66     8.9981       4          84     88  2012     12   
    
           hour  minute  second  
    0         0       0       0  
    1         1       0       0  
    2         2       0       0  
    3         3       0       0  
    4         4       0       0  
    ...     ...     ...     ...  
    10881    19       0       0  
    10882    20       0       0  
    10883    21       0       0  
    10884    22       0       0  
    10885    23       0       0  
    
    [10886 rows x 17 columns]
    


```python
tr1[tr1['year']==2011]['casual']
tr1[tr1['year']==2011]['registered']
tr1[tr1['year']==2011]['count']
```




    0        16
    1        40
    2        32
    3        13
    4         1
           ... 
    5417    251
    5418    206
    5419    127
    5420    107
    5421     60
    Name: count, Length: 5422, dtype: int64




```python
cs_2011=tr1[tr1['year']==2011]['casual'].mean()
rgst_2011=tr1[tr1['year']==2011]['registered'].mean()
total_2011=tr1[tr1['year']==2011]['count'].mean()
```


```python
print(cs_2011)
print(rgst_2011)
print(total_2011)
```

    28.737919586868315
    115.48542973072666
    144.223349317595
    


```python
cs_2012=tr1[tr1['year']==2012]['casual'].mean()
rgst_2012=tr1[tr1['year']==2012]['registered'].mean()
total_2012=tr1[tr1['year']==2012]['count'].mean()
```


```python
print(cs_2012)
print(rgst_2012)
print(total_2012)
```

    43.25
    195.31094436310394
    238.56094436310394
    


```python
tr1_2011=tr1[tr1['year']==2011]
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    ~\Anaconda3\lib\site-packages\pandas\core\indexes\base.py in get_loc(self, key, method, tolerance)
       2896             try:
    -> 2897                 return self._engine.get_loc(key)
       2898             except KeyError:
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    KeyError: 'year'

    
    During handling of the above exception, another exception occurred:
    

    KeyError                                  Traceback (most recent call last)

    <ipython-input-12-6332a7e9e55b> in <module>
    ----> 1 tr1_2011=tr1[tr1['year']==2011]
    

    ~\Anaconda3\lib\site-packages\pandas\core\frame.py in __getitem__(self, key)
       2978             if self.columns.nlevels > 1:
       2979                 return self._getitem_multilevel(key)
    -> 2980             indexer = self.columns.get_loc(key)
       2981             if is_integer(indexer):
       2982                 indexer = [indexer]
    

    ~\Anaconda3\lib\site-packages\pandas\core\indexes\base.py in get_loc(self, key, method, tolerance)
       2897                 return self._engine.get_loc(key)
       2898             except KeyError:
    -> 2899                 return self._engine.get_loc(self._maybe_cast_indexer(key))
       2900         indexer = self.get_indexer([key], method=method, tolerance=tolerance)
       2901         if indexer.ndim > 1 or indexer.size > 1:
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    KeyError: 'year'



```python
tr1_2012=tr1[tr1['year']==2012]
tr1_2012[tr1_2012['month']==1]      <-2012년 중 1월의 데이터
tr1_2011[tr1_2011['month']==2]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
      <th>year</th>
      <th>month</th>
      <th>hour</th>
      <th>minute</th>
      <th>second</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>431</td>
      <td>2011-02-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6.56</td>
      <td>9.090</td>
      <td>64</td>
      <td>7.0015</td>
      <td>2</td>
      <td>6</td>
      <td>8</td>
      <td>2011</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>432</td>
      <td>2011-02-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6.56</td>
      <td>9.090</td>
      <td>69</td>
      <td>7.0015</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>2011</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>433</td>
      <td>2011-02-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6.56</td>
      <td>11.365</td>
      <td>69</td>
      <td>0.0000</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>2011</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>434</td>
      <td>2011-02-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6.56</td>
      <td>11.365</td>
      <td>69</td>
      <td>0.0000</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>2011</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>435</td>
      <td>2011-02-01 05:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>5.74</td>
      <td>10.605</td>
      <td>93</td>
      <td>0.0000</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>2011</td>
      <td>2</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>872</td>
      <td>2011-02-19 19:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>13.94</td>
      <td>15.150</td>
      <td>29</td>
      <td>23.9994</td>
      <td>5</td>
      <td>54</td>
      <td>59</td>
      <td>2011</td>
      <td>2</td>
      <td>19</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>873</td>
      <td>2011-02-19 20:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>13.12</td>
      <td>14.395</td>
      <td>28</td>
      <td>35.0008</td>
      <td>9</td>
      <td>38</td>
      <td>47</td>
      <td>2011</td>
      <td>2</td>
      <td>20</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>874</td>
      <td>2011-02-19 21:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>13.12</td>
      <td>13.635</td>
      <td>26</td>
      <td>36.9974</td>
      <td>4</td>
      <td>29</td>
      <td>33</td>
      <td>2011</td>
      <td>2</td>
      <td>21</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>875</td>
      <td>2011-02-19 22:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>12.30</td>
      <td>12.880</td>
      <td>28</td>
      <td>32.9975</td>
      <td>2</td>
      <td>42</td>
      <td>44</td>
      <td>2011</td>
      <td>2</td>
      <td>22</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>876</td>
      <td>2011-02-19 23:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>11.48</td>
      <td>12.120</td>
      <td>33</td>
      <td>30.0026</td>
      <td>4</td>
      <td>25</td>
      <td>29</td>
      <td>2011</td>
      <td>2</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>446 rows × 17 columns</p>
</div>




```python

```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-220-f67948533240> in <module>
    ----> 1 plot(tr1['datetime'],tr1['holiday'])
    

    NameError: name 'plot' is not defined



```python
cs_2012_monthly=[]
rgst_2012_monthly=[]
total_2012_monthly=[]
for i in range(1,13):
    cs_2012_monthly.append(tr1_2012[tr1_2012['month']==i]['casual'].mean())
for i in range(1,13):
    rgst_2012_monthly.append(tr1_2012[tr1_2012['month']==i]['registered'].mean())
for i in range(1,13):
    total_2012_monthly.append(tr1_2012[tr1_2012['month']==i]['count'].mean())  
```


```python
cs_2011_monthly=[]
rgst_2011_monthly=[]
total_2011_monthly=[]
for i in range(1,13):
    cs_2011_monthly.append(tr1_2011[tr1_2011['month']==i]['casual'].mean())
for i in range(1,13):
    rgst_2011_monthly.append(tr1_2011[tr1_2011['month']==i]['registered'].mean())
for i in range(1,13):
    total_2011_monthly.append(tr1_2011[tr1_2011['month']==i]['count'].mean())  
```


```python
tr1_2011[tr1_2011['datetime'].dt.day==1]    <-2011 1일의 데이터들
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
      <th>year</th>
      <th>month</th>
      <th>hour</th>
      <th>minute</th>
      <th>second</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0000</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
      <td>2011</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0000</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
      <td>2011</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0000</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
      <td>2011</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0000</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
      <td>2011</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0000</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2011</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>4985</td>
      <td>2011-12-01 19:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>17.425</td>
      <td>46</td>
      <td>7.0015</td>
      <td>9</td>
      <td>219</td>
      <td>228</td>
      <td>2011</td>
      <td>12</td>
      <td>19</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>4986</td>
      <td>2011-12-01 20:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>17.425</td>
      <td>46</td>
      <td>7.0015</td>
      <td>12</td>
      <td>178</td>
      <td>190</td>
      <td>2011</td>
      <td>12</td>
      <td>20</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>4987</td>
      <td>2011-12-01 21:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>12.30</td>
      <td>15.910</td>
      <td>61</td>
      <td>7.0015</td>
      <td>8</td>
      <td>154</td>
      <td>162</td>
      <td>2011</td>
      <td>12</td>
      <td>21</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>4988</td>
      <td>2011-12-01 22:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>12.30</td>
      <td>16.665</td>
      <td>61</td>
      <td>0.0000</td>
      <td>5</td>
      <td>99</td>
      <td>104</td>
      <td>2011</td>
      <td>12</td>
      <td>22</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>4989</td>
      <td>2011-12-01 23:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>10.66</td>
      <td>14.395</td>
      <td>70</td>
      <td>6.0032</td>
      <td>3</td>
      <td>70</td>
      <td>73</td>
      <td>2011</td>
      <td>12</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>287 rows × 17 columns</p>
</div>




```python
tr1_2011[tr1_2011['month']==2]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
      <th>year</th>
      <th>month</th>
      <th>hour</th>
      <th>minute</th>
      <th>second</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>431</td>
      <td>2011-02-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6.56</td>
      <td>9.090</td>
      <td>64</td>
      <td>7.0015</td>
      <td>2</td>
      <td>6</td>
      <td>8</td>
      <td>2011</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>432</td>
      <td>2011-02-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6.56</td>
      <td>9.090</td>
      <td>69</td>
      <td>7.0015</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>2011</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>433</td>
      <td>2011-02-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6.56</td>
      <td>11.365</td>
      <td>69</td>
      <td>0.0000</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>2011</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>434</td>
      <td>2011-02-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6.56</td>
      <td>11.365</td>
      <td>69</td>
      <td>0.0000</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>2011</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>435</td>
      <td>2011-02-01 05:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>5.74</td>
      <td>10.605</td>
      <td>93</td>
      <td>0.0000</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>2011</td>
      <td>2</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>872</td>
      <td>2011-02-19 19:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>13.94</td>
      <td>15.150</td>
      <td>29</td>
      <td>23.9994</td>
      <td>5</td>
      <td>54</td>
      <td>59</td>
      <td>2011</td>
      <td>2</td>
      <td>19</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>873</td>
      <td>2011-02-19 20:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>13.12</td>
      <td>14.395</td>
      <td>28</td>
      <td>35.0008</td>
      <td>9</td>
      <td>38</td>
      <td>47</td>
      <td>2011</td>
      <td>2</td>
      <td>20</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>874</td>
      <td>2011-02-19 21:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>13.12</td>
      <td>13.635</td>
      <td>26</td>
      <td>36.9974</td>
      <td>4</td>
      <td>29</td>
      <td>33</td>
      <td>2011</td>
      <td>2</td>
      <td>21</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>875</td>
      <td>2011-02-19 22:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>12.30</td>
      <td>12.880</td>
      <td>28</td>
      <td>32.9975</td>
      <td>2</td>
      <td>42</td>
      <td>44</td>
      <td>2011</td>
      <td>2</td>
      <td>22</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>876</td>
      <td>2011-02-19 23:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>11.48</td>
      <td>12.120</td>
      <td>33</td>
      <td>30.0026</td>
      <td>4</td>
      <td>25</td>
      <td>29</td>
      <td>2011</td>
      <td>2</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>446 rows × 17 columns</p>
</div>




```python
tr1_2011['casual'][tr1_2011['datetime'].dt.day==1]
```




    0        3
    1        8
    2        5
    3        3
    4        0
            ..
    4985     9
    4986    12
    4987     8
    4988     5
    4989     3
    Name: casual, Length: 287, dtype: int64




```python
cs_2011_daily=[]
rgst_2011_daily=[]
total_2011_daily=[]
for i in range(1,20):
    cs_2011_daily.append(tr1_2011['casual'][tr1_2011['datetime'].dt.day==i].mean())
for i in range(1,20):
    rgst_2011_daily.append(tr1_2011['registered'][tr1_2011['datetime'].dt.day==i].mean())
for i in range(1,20):
    total_2011_daily.append(tr1_2011['count'][tr1_2011['datetime'].dt.day==i].mean())  
```


```python
cs_2012_daily=[]
rgst_2012_daily=[]
total_2012_daily=[]
for i in range(1,20):
    cs_2012_daily.append(tr1_2012['casual'][tr1_2012['datetime'].dt.day==i].mean())
for i in range(1,20):
    rgst_2012_daily.append(tr1_2012['registered'][tr1_2012['datetime'].dt.day==i].mean())
for i in range(1,20):
    total_2012_daily.append(tr1_2012['count'][tr1_2012['datetime'].dt.day==i].mean()) 
```


```python
cs_2011_hourly=[]
rgst_2011_hourly=[]
total_2011_hourly=[]
for i in range(1,25):
    cs_2011_hourly.append(tr1_2011['casual'][tr1_2011['datetime'].dt.hour==i].mean())
for i in range(1,25):
    rgst_2011_hourly.append(tr1_2011['registered'][tr1_2011['datetime'].dt.hour==i].mean())
for i in range(1,25):
    total_2011_hourly.append(tr1_2011['count'][tr1_2011['datetime'].dt.hour==i].mean()) 
```


```python
cs_2012_hourly=[]
rgst_2012_hourly=[]
total_2012_hourly=[]
for i in range(1,25):
    cs_2012_hourly.append(tr1_2012['casual'][tr1_2012['datetime'].dt.hour==i].mean())
for i in range(1,25):
    rgst_2012_hourly.append(tr1_2012['registered'][tr1_2012['datetime'].dt.hour==i].mean())
for i in range(1,25):
    total_2012_hourly.append(tr1_2012['count'][tr1_2012['datetime'].dt.hour==i].mean()) 
```


```python
cs_2012_hourly
```




    [7.25,
     4.977973568281938,
     2.581081081081081,
     1.303964757709251,
     1.631578947368421,
     4.298245614035087,
     11.570175438596491,
     23.850877192982455,
     37.24122807017544,
     56.44298245614035,
     74.25,
     85.3201754385965,
     92.01754385964912,
     94.52631578947368,
     94.57456140350877,
     92.32894736842105,
     91.3157894736842,
     73.44736842105263,
     58.21491228070175,
     42.64473684210526,
     32.824561403508774,
     25.885964912280702,
     17.04385964912281,
     nan]




```python
import matplotlib.pyplot as plt
```


```python
cs_2012_hourly
```




    [7.25,
     4.977973568281938,
     2.581081081081081,
     1.303964757709251,
     1.631578947368421,
     4.298245614035087,
     11.570175438596491,
     23.850877192982455,
     37.24122807017544,
     56.44298245614035,
     74.25,
     85.3201754385965,
     92.01754385964912,
     94.52631578947368,
     94.57456140350877,
     92.32894736842105,
     91.3157894736842,
     73.44736842105263,
     58.21491228070175,
     42.64473684210526,
     32.824561403508774,
     25.885964912280702,
     17.04385964912281,
     nan]




```python
plt.xlabel("time table")
plt.ylabel("No_of_eachrental")
plt.title("2011_hourly_rental")
plt.plot(cs_2011_hourly)
plt.plot(rgst_2011_hourly)
plt.plot(total_2011_hourly)
```




    [<matplotlib.lines.Line2D at 0x2c962173a48>]




![png](output_46_1.png)



```python
*분석결과: 2011년의 평균 사용량을 시간별로 분석하면 오전 7시와 오후 4시에 많은 사용량을 보인다
    이유은 많은 고객들이 출근길과 퇴근길에 자전거를 사용해서 이다.
```


```python
plt.xlabel("time table")
plt.ylabel("No_of_eachrental")
plt.title("2012_hourly_rental")
plt.plot(cs_2012_hourly)
plt.plot(rgst_2012_hourly)
plt.plot(total_2012_hourly)
```




    [<matplotlib.lines.Line2D at 0x2c9621dfac8>]




![png](output_48_1.png)



```python
*분석결과: 2012년의 평균 사용량을 시간별로 분석하면 오전 7시와 오후 4시에 많은 사용량을 보인다
    이유은 많은 고객들이 출근길과 퇴근길에 자전거를 사용해서 이다.
```


```python
plt.xlabel("time table")
plt.ylabel("No_of_eachrental")
plt.title("2011_daily_rental")
plt.plot(cs_2011_daily)
plt.plot(rgst_2011_daily)
plt.plot(total_2011_daily)
```




    [<matplotlib.lines.Line2D at 0x2c96239bbc8>]




![png](output_50_1.png)



```python
*분석결과: 2011년의 평균 사용량을 일별로 분석하면 일정한 사용량을 보인다.
    이유은 많은 요일에 따라 사용양이 크게 변하지 않기 때문이다.
    또한 casual사용자 보다 registered사용자가 전체의 많은 비중을 차지하는 것으로 보인다.
```


```python
plt.xlabel("time table")
plt.ylabel("No_of_eachrental")
plt.title("2012_hourly_rental")
plt.plot(cs_2012_daily)
plt.plot(rgst_2012_daily)
plt.plot(total_2012_daily)
```




    [<matplotlib.lines.Line2D at 0x2c962478c48>]




![png](output_52_1.png)



```python
*분석결과: 2012년의 평균 사용량을 일별로 분석하면 일정한 사용량을 보인다.
    이유은 많은 요일에 따라 사용양이 크게 변하지 않기 때문이다.
    또한 casual사용자 보다 registered사용자가 전체의 많은 비중을 차지하는 것으로 보인다.
```


```python
plt.xlabel("time table")
plt.ylabel("No_of_eachrental")
plt.title("2011_monthly_rental")
plt.plot(cs_2011_monthly)
plt.plot(rgst_2011_monthly)
plt.plot(total_2011_monthly)
```




    [<matplotlib.lines.Line2D at 0x2c96352cf08>]




![png](output_54_1.png)



```python
*분석결과: 2011년의 평균 사용량을 월별로 분석하면 봄시즌인 2월부터 사용량이 늘어나 6월 
    최대 사용량을 이룬 후 점차 내려가는 추세를 볼 수 있다.
    이유은 봄과 여름에 자전거를 타기 좋은 날씨이고 계절이 점점 추워지며 사용량이 줄어들기 
    때문이다.
```


```python
plt.xlabel("time table")
plt.ylabel("No_of_eachrental")
plt.title("2012_monthly_rental")
plt.plot(cs_2012_monthly)
plt.plot(rgst_2012_monthly)
plt.plot(total_2012_monthly)
```




    [<matplotlib.lines.Line2D at 0x2c96360dc08>]




![png](output_56_1.png)



```python
*분석결과: 2012년의 평균 사용량을 월별로 분석하면 봄시즌인 2월부터 사용량이 늘어나 6월 
    최대 사용량을 이룬 후 점차 내려가는 추세를 볼 수 있다.
    이유은 봄과 여름에 자전거를 타기 좋은 날씨이고 계절이 점점 추워지며 사용량이 줄어들기 
    때문이다.
```


```python
4.근무일 유무/요일/시즌/날씨에 따른 시간대별 자전거 대여량 구하기
```


```python
tr1_holiday1=tr1[tr1['holiday']==1]
tr1_holiday1_hourly=[]
for i in range(1,24):
    tr1_holiday1_hourly.append(tr1_holiday1[tr1_holiday1['datetime'].dt.hour==i]['count'].mean())
tr1_holiday1_hourly
```




    [43.23076923076923,
     28.0,
     12.416666666666666,
     7.384615384615385,
     13.23076923076923,
     38.92307692307692,
     111.0,
     229.0,
     211.30769230769232,
     230.53846153846155,
     274.84615384615387,
     318.38461538461536,
     326.38461538461536,
     321.0769230769231,
     292.7692307692308,
     314.84615384615387,
     368.0,
     344.53846153846155,
     280.2307692307692,
     219.15384615384616,
     181.84615384615384,
     141.3846153846154,
     72.46153846153847]




```python
tr1_holiday0=tr1[tr1['holiday']==0]
tr1_holiday0_hourly=[]
for i in range(1,24):
    tr1_holiday0_hourly.append(tr1_holiday0[tr1_holiday0['datetime'].dt.hour==i]['count'].mean())
tr1_holiday0_hourly
```




    [33.5827664399093,
     22.74712643678161,
     11.738717339667458,
     6.3776223776223775,
     19.96127562642369,
     77.35746606334841,
     216.11990950226243,
     366.70361990950227,
     222.08823529411765,
     173.46153846153845,
     208.78733031674207,
     254.69300225733633,
     255.77426636568848,
     241.1647855530474,
     253.16930022573362,
     316.4176072234763,
     471.72234762979684,
     433.392776523702,
     316.30699774266367,
     228.7923250564334,
     173.12189616252823,
     133.34762979683973,
     90.00902934537245]




```python
tr1_workingday0=tr1[tr1['workingday']==0]
tr1_workingday0_hourly=[]
for i in range(1,24):
    tr1_workingday0_hourly.append(tr1_workingday0[tr1_workingday0['datetime'].dt.hour==i]['count'].mean())
tr1_workingday0_hourly
```




    [71.9103448275862,
     53.74825174825175,
     25.53472222222222,
     8.544827586206896,
     9.373239436619718,
     19.99310344827586,
     47.26896551724138,
     112.2551724137931,
     177.9241379310345,
     263.80689655172415,
     325.3862068965517,
     379.11034482758623,
     387.82068965517243,
     378.7310344827586,
     373.70344827586206,
     367.64827586206894,
     339.1241379310345,
     292.24827586206897,
     242.3448275862069,
     183.80689655172415,
     148.73793103448276,
     123.35172413793103,
     90.60689655172413]




```python
tr1_workingday1=tr1[tr1['workingday']==1]
tr1_workingday1_hourly=[]
for i in range(1,24):
    tr1_workingday1_hourly.append(tr1_workingday1[tr1_workingday1['datetime'].dt.hour==i]['count'].mean())
tr1_workingday1_hourly
```




    [16.003236245954692,
     8.436065573770492,
     4.892733564013841,
     5.363636363636363,
     24.529032258064515,
     102.57741935483871,
     290.69032258064516,
     479.9451612903226,
     242.29354838709676,
     133.59677419354838,
     157.0193548387097,
     199.34726688102893,
     197.16077170418006,
     180.36655948553056,
     198.62700964630224,
     292.4662379421222,
     529.2090032154341,
     495.4855305466238,
     349.2829581993569,
     249.36334405144694,
     184.85530546623795,
     138.34405144694534,
     88.9967845659164]




```python
plt.plot(tr1_workingday1_hourly)
```




    [<matplotlib.lines.Line2D at 0x2c96414cb08>]




![png](output_63_1.png)



```python
plt.plot(tr1_holiday1_hourly)
```




    [<matplotlib.lines.Line2D at 0x2c9641a7588>]




![png](output_64_1.png)



```python
#tr1_workingday1_hourly.append(tr1_workingday1[tr1_workingday1['datetime'].dt.hour==i]['count'].mean())
tr1_day1=tr1[tr1['datetime'].dt.day==1]
tr1_day2=tr1[tr1['datetime'].dt.day==2]
tr1_day=[]
for i in range(1,24):
    tr1_day.append(tr1[tr1['datetime'].dt.day==i])

```


```python
tr1_holiday1=tr1[tr1['holiday']==1]
tr1_holiday1_hourly=[]
for i in range(1,24):
    tr1_holiday1_hourly.append(tr1_holiday1[tr1_holiday1['datetime'].dt.hour==i]['count'].mean())
tr1_holiday1_hourly
```


```python
tr1_day1_hourly=[]
for i in range(1,24):
    tr1_day1_hourly.append(tr1_day[0][tr1_day[0].datetime.dt.hour==i]['count'].mean())
tr1_day1_hourly
```




    [34.25,
     28.083333333333332,
     13.291666666666666,
     6.304347826086956,
     19.416666666666668,
     74.20833333333333,
     197.91666666666666,
     354.5,
     215.70833333333334,
     168.04166666666666,
     199.625,
     238.08333333333334,
     243.41666666666666,
     234.625,
     247.95833333333334,
     293.3333333333333,
     437.25,
     390.4166666666667,
     290.5,
     207.75,
     159.83333333333334,
     122.04166666666667,
     88.33333333333333]




```python
tr1_day2_hourly=[]
for i in range(1,24):
    tr1_day2_hourly.append(tr1_day[1][tr1_day[1].datetime.dt.hour==i]['count'].mean())
tr1_day3_hourly=[]
for i in range(1,24):
    tr1_day3_hourly.append(tr1_day[2][tr1_day[2].datetime.dt.hour==i]['count'].mean())
tr1_day4_hourly=[]
for i in range(1,24):
    tr1_day4_hourly.append(tr1_day[3][tr1_day[3].datetime.dt.hour==i]['count'].mean())
tr1_day5_hourly=[]
for i in range(1,24):
    tr1_day5_hourly.append(tr1_day[4][tr1_day[4].datetime.dt.hour==i]['count'].mean())
tr1_day6_hourly=[]
for i in range(1,24):
    tr1_day6_hourly.append(tr1_day[5][tr1_day[5].datetime.dt.hour==i]['count'].mean())
tr1_day19_hourly=[]
for i in range(1,24):
    tr1_day19_hourly.append(tr1_day[18][tr1_day[18].datetime.dt.hour==i]['count'].mean())

```


```python
tr1_season1=tr1[tr1['season']==1]
tr1_season2=tr1[tr1['season']==2]
tr1_season3=tr1[tr1['season']==3]
tr1_season4=tr1[tr1['season']==4]
```


```python
tr1_season1_hourly=[]
for i in range(1,24):
     tr1_season1_hourly.append(tr1_season1[tr1_season1['datetime'].dt.hour==i]['count'].mean())
```


```python
tr1_season2_hourly=[]
for i in range(1,24):
     tr1_season2_hourly.append(tr1_season2[tr1_season2['datetime'].dt.hour==i]['count'].mean())
```


```python
tr1_season3_hourly=[]
for i in range(1,24):
     tr1_season3_hourly.append(tr1_season3[tr1_season3['datetime'].dt.hour==i]['count'].mean())
```


```python
tr1_season4_hourly=[]
for i in range(1,24):
     tr1_season4_hourly.append(tr1_season4[tr1_season4['datetime'].dt.hour==i]['count'].mean())
```


```python
tr1_season4_hourly
```




    [36.166666666666664,
     22.68421052631579,
     11.169642857142858,
     7.228070175438597,
     22.333333333333332,
     82.25438596491227,
     230.9561403508772,
     403.0701754385965,
     241.07894736842104,
     186.2982456140351,
     223.3684210526316,
     278.57894736842104,
     275.96491228070175,
     264.20175438596493,
     277.7368421052632,
     346.36842105263156,
     485.9035087719298,
     426.67543859649123,
     299.359649122807,
     214.56140350877192,
     162.87719298245614,
     126.41228070175438,
     89.29824561403508]




```python
weather - 1: Clear, 2:Few clouds, 3:Partly cloudy, 4:Partly cloudy
```


```python
tr1_clear=tr1[tr1['weather']==1]
tr1_fewcloud=tr1[tr1['weather']==2]
tr1_partlycloud=tr1[tr1['weather']==3]
tr1_cloudy=tr1[tr1['weather']==4]
```


```python
tr1_clear_hourly=[]
for i in range(1,24):
    tr1_clear_hourly.append(tr1_clear[tr1_clear['datetime'].\
                                      dt.hour==i]['count'].mean())
```


```python
tr1_fewcloud_hourly=[]
for i in range(1,24):
    tr1_fewcloud_hourly.append(tr1_fewcloud[tr1_fewcloud['datetime'].\
                                      dt.hour==i]['count'].mean())
```


```python
tr1_partlycloud_hourly=[]
for i in range(1,24):
    tr1_partlycloud_hourly.append(tr1_partlycloud[tr1_partlycloud['datetime'].\
                                      dt.hour==i]['count'].mean())
```


```python
tr1_cloudy_hourly=[]
for i in range(1,24):
    tr1_cloudy_hourly.append(tr1_cloudy[tr1_cloudy['datetime'].\
                                      dt.hour==i]['count'].mean())
```


```python
tr1_2011
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
      <th>year</th>
      <th>month</th>
      <th>hour</th>
      <th>minute</th>
      <th>second</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0000</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
      <td>2011</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0000</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
      <td>2011</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0000</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
      <td>2011</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0000</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
      <td>2011</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0000</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2011</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>5417</td>
      <td>2011-12-19 19:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>53</td>
      <td>11.0014</td>
      <td>17</td>
      <td>234</td>
      <td>251</td>
      <td>2011</td>
      <td>12</td>
      <td>19</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>5418</td>
      <td>2011-12-19 20:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>16.40</td>
      <td>20.455</td>
      <td>40</td>
      <td>11.0014</td>
      <td>9</td>
      <td>197</td>
      <td>206</td>
      <td>2011</td>
      <td>12</td>
      <td>20</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>5419</td>
      <td>2011-12-19 21:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>53</td>
      <td>8.9981</td>
      <td>15</td>
      <td>112</td>
      <td>127</td>
      <td>2011</td>
      <td>12</td>
      <td>21</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>5420</td>
      <td>2011-12-19 22:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>57</td>
      <td>11.0014</td>
      <td>12</td>
      <td>95</td>
      <td>107</td>
      <td>2011</td>
      <td>12</td>
      <td>22</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <td>5421</td>
      <td>2011-12-19 23:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>53</td>
      <td>11.0014</td>
      <td>10</td>
      <td>50</td>
      <td>60</td>
      <td>2011</td>
      <td>12</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5422 rows × 17 columns</p>
</div>




```python
tr1_2011=tr1[tr1['datetime'].dt.year==2011]
tr1_2012=tr1[tr1['datetime'].dt.year==2012]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>5422</td>
      <td>2012-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>14.76</td>
      <td>18.940</td>
      <td>66</td>
      <td>0.0000</td>
      <td>5</td>
      <td>43</td>
      <td>48</td>
    </tr>
    <tr>
      <td>5423</td>
      <td>2012-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>66</td>
      <td>8.9981</td>
      <td>15</td>
      <td>78</td>
      <td>93</td>
    </tr>
    <tr>
      <td>5424</td>
      <td>2012-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>13.12</td>
      <td>17.425</td>
      <td>76</td>
      <td>0.0000</td>
      <td>16</td>
      <td>59</td>
      <td>75</td>
    </tr>
    <tr>
      <td>5425</td>
      <td>2012-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>12.30</td>
      <td>16.665</td>
      <td>81</td>
      <td>0.0000</td>
      <td>11</td>
      <td>41</td>
      <td>52</td>
    </tr>
    <tr>
      <td>5426</td>
      <td>2012-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>11.48</td>
      <td>15.150</td>
      <td>81</td>
      <td>6.0032</td>
      <td>0</td>
      <td>8</td>
      <td>8</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>10881</td>
      <td>2012-12-19 19:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>15.58</td>
      <td>19.695</td>
      <td>50</td>
      <td>26.0027</td>
      <td>7</td>
      <td>329</td>
      <td>336</td>
    </tr>
    <tr>
      <td>10882</td>
      <td>2012-12-19 20:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>57</td>
      <td>15.0013</td>
      <td>10</td>
      <td>231</td>
      <td>241</td>
    </tr>
    <tr>
      <td>10883</td>
      <td>2012-12-19 21:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>15.910</td>
      <td>61</td>
      <td>15.0013</td>
      <td>4</td>
      <td>164</td>
      <td>168</td>
    </tr>
    <tr>
      <td>10884</td>
      <td>2012-12-19 22:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>17.425</td>
      <td>61</td>
      <td>6.0032</td>
      <td>12</td>
      <td>117</td>
      <td>129</td>
    </tr>
    <tr>
      <td>10885</td>
      <td>2012-12-19 23:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.12</td>
      <td>16.665</td>
      <td>66</td>
      <td>8.9981</td>
      <td>4</td>
      <td>84</td>
      <td>88</td>
    </tr>
  </tbody>
</table>
<p>5464 rows × 12 columns</p>
</div>




```python
tr1_2011_monthly=[]
for i in range(1,12):
    tr1_2011_monthly.append(tr1_2011[tr1_2011['datetime'].dt.month==i]\
    ['count'].mean())

```




    [54.64501160092807,
     73.64125560538116,
     86.84977578475336,
     111.02637362637363,
     174.80921052631578,
     196.87719298245614,
     203.6140350877193,
     182.66666666666666,
     174.6225165562914,
     174.77362637362637,
     155.45833333333334]




```python
tr1_2012_monthly=[]
for i in range(1,12):
    tr1_2012_monthly.append(tr1_2012\
    [tr1_2012['datetime'].dt.month==i]['count'].mean())
```


```python
tr1_2012_monthly
```




    [124.3532008830022,
     145.64615384615385,
     208.27692307692308,
     257.45594713656385,
     264.109649122807,
     287.18640350877195,
     267.0372807017544,
     285.5701754385965,
     292.5986842105263,
     280.50877192982455,
     231.98021978021978]




```python
from sklearn.preprocessing import *
```


```python
from scipy import stats
```


```python
tr1_hmdt=tr1['humidity']
tr1_hmdt['zscore']=stats.zscore(tr1['humidity'])

```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-68-adfbdba4045a> in <module>
          1 tr1_hmdt=tr1['humidity']
    ----> 2 tr1_hmdt['zscore']=stats.zscore(tr1['humidity'])
    

    ~\Anaconda3\lib\site-packages\scipy\stats\stats.py in zscore(a, axis, ddof)
       2313                 np.expand_dims(sstd, axis=axis))
       2314     else:
    -> 2315         return (a - mns) / sstd
       2316 
       2317 
    

    ValueError: operands could not be broadcast together with shapes (10887,) (10886,) 



```python

```
