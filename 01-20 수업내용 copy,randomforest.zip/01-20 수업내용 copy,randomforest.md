```python
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
```


```python
import pandas as pd
```


```python
train=pd.read_csv("trainbike.csv",parse_dates=["datetime"])
train.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10886 entries, 0 to 10885
    Data columns (total 12 columns):
    datetime      10886 non-null datetime64[ns]
    season        10886 non-null int64
    holiday       10886 non-null int64
    workingday    10886 non-null int64
    weather       10886 non-null int64
    temp          10886 non-null float64
    atemp         10886 non-null float64
    humidity      10886 non-null int64
    windspeed     10886 non-null float64
    casual        10886 non-null int64
    registered    10886 non-null int64
    count         10886 non-null int64
    dtypes: datetime64[ns](1), float64(3), int64(8)
    memory usage: 1020.7 KB
    


```python
train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
train.temp
```




    0         9.84
    1         9.02
    2         9.02
    3         9.84
    4         9.84
             ...  
    10881    15.58
    10882    14.76
    10883    13.94
    10884    13.94
    10885    13.12
    Name: temp, Length: 10886, dtype: float64




```python
train.describe()    
train.temp.describe()  <-"temp"라는 column에서만 기술통계가 이루어짐
```




    count    10886.00000
    mean        20.23086
    std          7.79159
    min          0.82000
    25%         13.94000
    50%         20.50000
    75%         26.24000
    max         41.00000
    Name: temp, dtype: float64




```python
train.isnull().sum()
import missingno as msno
msno.matrix(train,figsize=(12,5))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18df3e83d48>




![png](output_6_1.png)



```python
train['year']=train['datetime'].dt.year
train['month']=train['datetime'].dt.month
train['day']=train['datetime'].dt.day
train['hour']=train['datetime'].dt.hour
train['minute']=train['datetime'].dt.minute
train['second']=train['datetime'].dt.second
```


```python
fig,((ax1,ax2,ax3),(ax4,ax5,ax6))=plt.subplots(nrows=2,ncols=3)   <-subplots는 여러표를 표시할때!
fig.set_size_inches(14,7)
sns.barplot(data=train,x='year',y='count',ax=ax1)
sns.barplot(data=train,x='month',y='count',ax=ax2)
sns.barplot(data=train,x='day',y='count',ax=ax3)
sns.barplot(data=train,x='hour',y='count',ax=ax4)
sns.barplot(data=train,x='minute',y='count',ax=ax5)
sns.barplot(data=train,x='second',y='count',ax=ax6)  <- 분,초는 0으로 되어있어서 의미 없음
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18df4f4e5c8>




![png](output_8_1.png)



```python
fig,((ax1,ax2,ax3),(ax4,ax5,ax6))=plt.subplots(nrows=2,ncols=3)   
fig.set_size_inches(14,7)
```


![png](output_9_0.png)



```python
fig,axes=plt.subplots(nrows=2,ncols=2)  
fig.set_size_inches(14,7)
sns.boxplot(data=train, x='season',y='count',ax=axes[0][0])
sns.boxplot(data=train, x='workingday',y='count',ax=axes[0][1])
sns.boxplot(data=train, orient="v",y='count',ax=axes[1][0])  <-orient는 방향 "v"는 vertical의 v
sns.boxplot(data=train, x='hour',y='count',ax=axes[1][1])
=> boxplot은 2,3분위수 이상치 등을 한번에 볼 수 있음,
선 밖으로 점들이 몇 개 있음
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18df60bc608>




![png](output_10_1.png)



```python
train['dayofweek']=train['datetime'].dt.dayofweek
```


```python
train
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
      <th>year</th>
      <th>month</th>
      <th>day</th>
      <th>hour</th>
      <th>minute</th>
      <th>second</th>
      <th>dayofweek</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0000</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
      <td>2011</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0000</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
      <td>2011</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0000</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
      <td>2011</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0000</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
      <td>2011</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0000</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>2011</td>
      <td>1</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>10881</td>
      <td>2012-12-19 19:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>15.58</td>
      <td>19.695</td>
      <td>50</td>
      <td>26.0027</td>
      <td>7</td>
      <td>329</td>
      <td>336</td>
      <td>2012</td>
      <td>12</td>
      <td>19</td>
      <td>19</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <td>10882</td>
      <td>2012-12-19 20:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>57</td>
      <td>15.0013</td>
      <td>10</td>
      <td>231</td>
      <td>241</td>
      <td>2012</td>
      <td>12</td>
      <td>19</td>
      <td>20</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <td>10883</td>
      <td>2012-12-19 21:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>15.910</td>
      <td>61</td>
      <td>15.0013</td>
      <td>4</td>
      <td>164</td>
      <td>168</td>
      <td>2012</td>
      <td>12</td>
      <td>19</td>
      <td>21</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <td>10884</td>
      <td>2012-12-19 22:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>17.425</td>
      <td>61</td>
      <td>6.0032</td>
      <td>12</td>
      <td>117</td>
      <td>129</td>
      <td>2012</td>
      <td>12</td>
      <td>19</td>
      <td>22</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <td>10885</td>
      <td>2012-12-19 23:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.12</td>
      <td>16.665</td>
      <td>66</td>
      <td>8.9981</td>
      <td>4</td>
      <td>84</td>
      <td>88</td>
      <td>2012</td>
      <td>12</td>
      <td>19</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>10886 rows × 19 columns</p>
</div>




```python
train['dayofweek'].unique()
```




    array([5, 6, 0, 1, 2, 3, 4], dtype=int64)




```python
train['dayofweek'].value_counts()
```




    5    1584
    6    1579
    3    1553
    2    1551
    0    1551
    1    1539
    4    1529
    Name: dayofweek, dtype: int64




```python
fig,ax1=plt.subplots(nrows=1)
fig.set_size_inches(11,18)
sns.pointplot(data=train,x='hour',y='count',ax=ax1)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18df7e52b48>




![png](output_15_1.png)



```python
fig,(ax1,ax2)=plt.subplots(nrows=2)
fig.set_size_inches(8,16)
sns.pointplot(data=train,x='hour',y='count',ax=ax1)
sns.pointplot(data=train,x='hour',y='count',hue='workingday',ax=ax2)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18df7a33d48>




![png](output_16_1.png)



```python
fig,(ax1,ax2,ax3)=plt.subplots(nrows=3)
fig.set_size_inches(8,16)
sns.pointplot(data=train,x='hour',y='count',ax=ax1)
sns.pointplot(data=train,x='hour',y='count',hue='workingday',ax=ax2)
sns.pointplot(data=train,x='hour',y='count',hue='dayofweek',ax=ax3)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18df7c90b08>




![png](output_17_1.png)



```python
fig,(ax1,ax2,ax3,ax4)=plt.subplots(nrows=4)
fig.set_size_inches(8,16)
sns.pointplot(data=train,x='hour',y='count',ax=ax1)
sns.pointplot(data=train,x='hour',y='count',hue='workingday',ax=ax2)
sns.pointplot(data=train,x='hour',y='count',hue='dayofweek',ax=ax3)
sns.pointplot(data=train,x='hour',y='count',hue='weather',ax=ax4)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18df9290608>




![png](output_18_1.png)



```python
fig,(ax1,ax2,ax3,ax4,ax5)=plt.subplots(nrows=5)
fig.set_size_inches(8,16)
sns.pointplot(data=train,x='hour',y='count',ax=ax1)
sns.pointplot(data=train,x='hour',y='count',hue='workingday',ax=ax2)
sns.pointplot(data=train,x='hour',y='count',hue='dayofweek',ax=ax3)
sns.pointplot(data=train,x='hour',y='count',hue='weather',ax=ax4)
sns.pointplot(data=train,x='hour',y='count',hue='season',ax=ax5)   <-hue는 기준을 의미함
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18dfa4bc348>




![png](output_19_1.png)



```python
fig,(ax1,ax2,ax3)=plt.subplots(ncols=3)
fig.set_size_inches(12,5)
sns.regplot(x="temp",y="count", data=train,ax=ax1)
sns.regplot(x="windspeed",y="count", data=train,ax=ax2)  <-windspeed는 0이 너무 많음 말이 안됨
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18dfc569a88>




![png](output_20_1.png)



```python
fig,(ax1,ax2,ax3)=plt.subplots(ncols=3)
fig.set_size_inches(12,5)
sns.regplot(x="temp",y="count", data=train,ax=ax1)
sns.regplot(x="windspeed",y="count", data=train,ax=ax2)
sns.regplot(x="humidity",y="count", data=train,ax=ax3)

```




    <matplotlib.axes._subplots.AxesSubplot at 0x18dfc067dc8>




![png](output_21_1.png)



```python
#train['year_month']=train['datetime']
def ym(mydt):
    return "{0}-{1}".format(mydt.year,mydt.month)
    
train['year_month']=train['datetime'].apply(ym)
train[['datetime','year_month']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>year_month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2011-01-01 00:00:00</td>
      <td>2011-1</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2011-01-01 01:00:00</td>
      <td>2011-1</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2011-01-01 02:00:00</td>
      <td>2011-1</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2011-01-01 03:00:00</td>
      <td>2011-1</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2011-01-01 04:00:00</td>
      <td>2011-1</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>10881</td>
      <td>2012-12-19 19:00:00</td>
      <td>2012-12</td>
    </tr>
    <tr>
      <td>10882</td>
      <td>2012-12-19 20:00:00</td>
      <td>2012-12</td>
    </tr>
    <tr>
      <td>10883</td>
      <td>2012-12-19 21:00:00</td>
      <td>2012-12</td>
    </tr>
    <tr>
      <td>10884</td>
      <td>2012-12-19 22:00:00</td>
      <td>2012-12</td>
    </tr>
    <tr>
      <td>10885</td>
      <td>2012-12-19 23:00:00</td>
      <td>2012-12</td>
    </tr>
  </tbody>
</table>
<p>10886 rows × 2 columns</p>
</div>




```python
fig,axes=plt.subplots(nrows=1,ncols=1)
fig.set_size_inches(16,5)
sns.barplot(data=train,x="year_month",y="count",ax=axes)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x18dfcd41708>




![png](output_23_1.png)



```python
*이상치(outliers) 제거
```


```python
import numpy as np
```


```python
trainWithoutOutliers=train[np.abs(train['count']-train['count'].mean())\
<=(train['count'].std()*3)]
```


```python
print(train.shape)
print(trainWithoutOutliers.shape)
```

    (10886, 20)
    (10739, 20)
    


```python
train 풍속=0인 것들
```


```python
train['windspeed'].mean()
```




    12.799395406945093




```python
train.loc[train['windspeed']==0,'windspeed']=train['windspeed']
train.loc[train['windspeed']!=0,'windspeed']         #평균으로 대체하는 코드 찾아보기
```


```python
train.loc[train['windspeed']!=0,'windspeed']
```




    5         6.0032
    10       16.9979
    11       19.0012
    12       19.0012
    13       19.9995
              ...   
    10881    26.0027
    10882    15.0013
    10883    15.0013
    10884     6.0032
    10885     8.9981
    Name: windspeed, Length: 9573, dtype: float64




```python
trainWind0
trainWindNot0
```


```python
trainWind0=train.loc[train['windspeed']==0]
trainWindNot0=train.loc[train['windspeed']!=0]
```


```python
trainWind0.shape
trainWindNot0.shape
```




    (1313, 20)




```python
*머신러닝의 랜덤포레스트로 풍속 예측
```


```python
from sklearn.ensemble import RandomForestClassifier

def predict_windspeed(data):
    #data의 windspeed값이 0인 데이터를
    #rf를 이용하여 예측한 값으로 대체
    
    #풍속 예측에 사용되는 변수
    wCol=['season','weather','humidity','month','temp','year','atemp']
    #풍속을 0인것과 0이 아닌 것으로 나눔
    dataWind0=data.loc[data['windspeed']==0]
    dataWindNot0=data.loc[data['windspeed']!=0]
    #randomforest분류기 생성
    rfModel=RandomForestClassifier()
    # wCol -> 풍속 학습 -> 모델 완성
    dataWindNot0['windspeed']=dataWindNot0['windspeed'].astype('str') #<- str으로 바꾸어줘야함
    rfModel.fit(dataWindNot0[wCol],dataWindNot0['windspeed']) #<-fit(A,B): A를 가지고 B를 학습
    #학습한 모델로 풍속 0에 대한 데이터 예측
    preValue=rfModel.predict(X=dataWind0[wCol])  #<-'X='는 입력값을 의미함
    print(preValue)
    predictWind0=dataWind0
    predictWindNot0=dataWindNot0
    
    predictWind0['windspeed']=preValue
    data=predictWindNot0.append(predictWind0)
    return data

train=predict_windspeed(train)
print(train.haed())
```

                     datetime  season  holiday  workingday  weather   temp  \
    0     2011-01-01 00:00:00       1        0           0        1   9.84   
    1     2011-01-01 01:00:00       1        0           0        1   9.02   
    2     2011-01-01 02:00:00       1        0           0        1   9.02   
    3     2011-01-01 03:00:00       1        0           0        1   9.84   
    4     2011-01-01 04:00:00       1        0           0        1   9.84   
    ...                   ...     ...      ...         ...      ...    ...   
    10881 2012-12-19 19:00:00       4        0           1        1  15.58   
    10882 2012-12-19 20:00:00       4        0           1        1  14.76   
    10883 2012-12-19 21:00:00       4        0           1        1  13.94   
    10884 2012-12-19 22:00:00       4        0           1        1  13.94   
    10885 2012-12-19 23:00:00       4        0           1        1  13.12   
    
            atemp  humidity  windspeed  casual  registered  count  year  month  \
    0      14.395        81     0.0000       3          13     16  2011      1   
    1      13.635        80     0.0000       8          32     40  2011      1   
    2      13.635        80     0.0000       5          27     32  2011      1   
    3      14.395        75     0.0000       3          10     13  2011      1   
    4      14.395        75     0.0000       0           1      1  2011      1   
    ...       ...       ...        ...     ...         ...    ...   ...    ...   
    10881  19.695        50    26.0027       7         329    336  2012     12   
    10882  17.425        57    15.0013      10         231    241  2012     12   
    10883  15.910        61    15.0013       4         164    168  2012     12   
    10884  17.425        61     6.0032      12         117    129  2012     12   
    10885  16.665        66     8.9981       4          84     88  2012     12   
    
           day  hour  minute  second  dayofweek year_month  
    0        1     0       0       0          5     2011-1  
    1        1     1       0       0          5     2011-1  
    2        1     2       0       0          5     2011-1  
    3        1     3       0       0          5     2011-1  
    4        1     4       0       0          5     2011-1  
    ...    ...   ...     ...     ...        ...        ...  
    10881   19    19       0       0          2    2012-12  
    10882   19    20       0       0          2    2012-12  
    10883   19    21       0       0          2    2012-12  
    10884   19    22       0       0          2    2012-12  
    10885   19    23       0       0          2    2012-12  
    
    [10886 rows x 20 columns]
    

    C:\Users\student\Anaconda3\lib\site-packages\ipykernel_launcher.py:15: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      from ipykernel import kernelapp as app
    C:\Users\student\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:245: FutureWarning: The default value of n_estimators will change from 10 in version 0.20 to 100 in 0.22.
      "10 in version 0.20 to 100 in 0.22.", FutureWarning)
    

    ['6.0032' '6.0032' '6.0032' ... '6.0032' '12.998' '6.0032']
    

    C:\Users\student\Anaconda3\lib\site-packages\ipykernel_launcher.py:23: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    


```python
print(train.head())
```

                  datetime  season  holiday  workingday  weather   temp   atemp  \
    5  2011-01-01 05:00:00       1        0           0        2   9.84  12.880   
    10 2011-01-01 10:00:00       1        0           0        1  15.58  19.695   
    11 2011-01-01 11:00:00       1        0           0        1  14.76  16.665   
    12 2011-01-01 12:00:00       1        0           0        1  17.22  21.210   
    13 2011-01-01 13:00:00       1        0           0        2  18.86  22.725   
    
        humidity windspeed  casual  registered  count  year  month  day  hour  \
    5         75    6.0032       0           1      1  2011      1    1     5   
    10        76   16.9979      12          24     36  2011      1    1    10   
    11        81   19.0012      26          30     56  2011      1    1    11   
    12        77   19.0012      29          55     84  2011      1    1    12   
    13        72   19.9995      47          47     94  2011      1    1    13   
    
        minute  second  dayofweek year_month  
    5        0       0          5     2011-1  
    10       0       0          5     2011-1  
    11       0       0          5     2011-1  
    12       0       0          5     2011-1  
    13       0       0          5     2011-1  
    


```python

```
