```python
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import pandas as pd
import numpy as np
```


```python
train=pd.read_csv("trainbike.csv",parse_dates=['datetime'])
test=pd.read_csv("testbike.csv",parse_dates=['datetime'])
tr1=train.copy()
te1=test.copy()
```


```python
tr1.shape
te1.shape
```




    (6493, 9)




```python
import missingno as msno
msno.matrix(tr1, figsize=(8,4))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x259e03bad88>




![png](output_3_1.png)



```python
te1.isnull().sum()
```




    datetime      0
    season        0
    holiday       0
    workingday    0
    weather       0
    temp          0
    atemp         0
    humidity      0
    windspeed     0
    dtype: int64




```python
*Feature Engineering
데이터 전처리, 파생변수 생성...

```


```python
tr1['year']=tr1['datetime'].dt.year
tr1['month']=tr1['datetime'].dt.month
tr1['day']=tr1['datetime'].dt.day
tr1['hour']=tr1['datetime'].dt.hour
tr1['minute']=tr1['datetime'].dt.minute
tr1['second']=tr1['datetime'].dt.second
tr1['dayofweek']=tr1['datetime'].dt.dayofweek

```


```python
te1['year']=te1['datetime'].dt.year
te1['month']=te1['datetime'].dt.month
te1['day']=te1['datetime'].dt.day
te1['hour']=te1['datetime'].dt.hour
te1['minute']=te1['datetime'].dt.minute
te1['second']=te1['datetime'].dt.second
te1['dayofweek']=te1['datetime'].dt.dayofweek
```


```python
te1.shape
```




    (6493, 16)




```python
fig,axes=plt.subplots(nrows=2)
fig.set_size_inches(12,7)
plt.sca(axes[0])
plt.xticks(rotation=50
          )
sns.countplot(data=tr1,x='windspeed',ax=axes[0])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x259db6585c8>




![png](output_9_1.png)



```python
fig,axes=plt.subplots(nrows=2)
fig.set_size_inches(12,7)
plt.sca(axes[1])     <-각도를 조정하는 코드
plt.xticks(rotation=50)
sns.countplot(data=tr1,x='windspeed',ax=axes[0])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x259dbfd5a88>




![png](output_10_1.png)



```python
fig,axes=plt.subplots(nrows=2)
fig.set_size_inches(12,7)
plt.sca(axes[0])
plt.xticks(rotation=50)
sns.countplot(data=te1,x='windspeed',ax=axes[0])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x259da6b5508>




![png](output_11_1.png)



```python
tr1Wind0=tr1.loc[tr1['windspeed']==0]
tr1WindNot0=tr1.loc[tr1['windspeed']!=0]
```


```python
from sklearn.ensemble import RandomForestClassifier
```


```python
def predict_windspeed(data):
    #data의 windspeed값이 0인 데이터를
    #rf를 이용하여 예측한 값으로 대체
    
    #풍속 예측에 사용되는 변수
    wCol=['season','weather','humidity','month','temp','year','atemp']
    #풍속을 0인것과 0이 아닌 것으로 나눔
    dataWind0=data.loc[data['windspeed']==0]
    dataWindNot0=data.loc[data['windspeed']!=0]
    #randomforest분류기 생성
    rfModel=RandomForestClassifier()
    # wCol -> 풍속 학습 -> 모델 완성
    dataWindNot0['windspeed']=dataWindNot0['windspeed'].astype('str') #<- str으로 바꾸어줘야함
    rfModel.fit(dataWindNot0[wCol],dataWindNot0['windspeed']) #<-fit(A,B): A를 가지고 B를 학습
    #학습한 모델로 풍속 0에 대한 데이터 예측
    preValue=rfModel.predict(X=dataWind0[wCol])  #<-'X='는 입력값을 의미함
    print(preValue)
    predictWind0=dataWind0
    predictWindNot0=dataWindNot0
    
    predictWind0['windspeed']=preValue
    data=predictWindNot0.append(predictWind0)
    data.reset_index(inplace=True)
    data.drop('index',inplace=True,axis=1)
    return data

tr1=predict_windspeed(tr1)
te1=predict_windspeed(te1)

```

    C:\Users\student\Anaconda3\lib\site-packages\ipykernel_launcher.py:13: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      del sys.path[0]
    C:\Users\student\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:245: FutureWarning: The default value of n_estimators will change from 10 in version 0.20 to 100 in 0.22.
      "10 in version 0.20 to 100 in 0.22.", FutureWarning)
    C:\Users\student\Anaconda3\lib\site-packages\ipykernel_launcher.py:21: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    C:\Users\student\Anaconda3\lib\site-packages\ipykernel_launcher.py:13: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      del sys.path[0]
    C:\Users\student\Anaconda3\lib\site-packages\sklearn\ensemble\forest.py:245: FutureWarning: The default value of n_estimators will change from 10 in version 0.20 to 100 in 0.22.
      "10 in version 0.20 to 100 in 0.22.", FutureWarning)
    

    ['6.0032' '6.0032' '6.0032' ... '8.9981' '6.0032' '6.0032']
    ['11.0014' '11.0014' '7.0015' '11.0014' '23.9994' '39.0007' '11.0014'
     '8.9981' '8.9981' '15.0013' '15.0013' '7.0015' '12.998' '12.998' '7.0015'
     '11.0014' '6.0032' '8.9981' '11.0014' '6.0032' '6.0032' '6.0032' '6.0032'
     '6.0032' '6.0032' '6.0032' '6.0032' '7.0015' '8.9981' '7.0015' '7.0015'
     '6.0032' '6.0032' '16.9979' '11.0014' '8.9981' '7.0015' '6.0032' '6.0032'
     '6.0032' '7.0015' '12.998' '12.998' '7.0015' '7.0015' '7.0015' '6.0032'
     '6.0032' '7.0015' '6.0032' '6.0032' '12.998' '7.0015' '8.9981' '19.0012'
     '6.0032' '6.0032' '12.998' '12.998' '22.0028' '15.0013' '11.0014'
     '11.0014' '7.0015' '12.998' '7.0015' '11.0014' '7.0015' '11.0014'
     '6.0032' '11.0014' '11.0014' '7.0015' '7.0015' '6.0032' '6.0032' '6.0032'
     '7.0015' '6.0032' '6.0032' '15.0013' '15.0013' '8.9981' '7.0015'
     '15.0013' '16.9979' '16.9979' '7.0015' '7.0015' '12.998' '12.998'
     '6.0032' '12.998' '6.0032' '6.0032' '19.0012' '16.9979' '19.0012'
     '6.0032' '8.9981' '11.0014' '11.0014' '11.0014' '8.9981' '8.9981'
     '12.998' '6.0032' '11.0014' '7.0015' '19.0012' '19.0012' '19.9995'
     '8.9981' '7.0015' '7.0015' '8.9981' '19.0012' '19.0012' '8.9981' '8.9981'
     '7.0015' '8.9981' '8.9981' '12.998' '7.0015' '19.9995' '19.9995' '12.998'
     '12.998' '12.998' '12.998' '8.9981' '16.9979' '15.0013' '15.0013'
     '15.0013' '8.9981' '11.0014' '7.0015' '7.0015' '15.0013' '6.0032'
     '16.9979' '15.0013' '12.998' '12.998' '12.998' '26.0027' '7.0015'
     '19.9995' '8.9981' '7.0015' '6.0032' '11.0014' '6.0032' '6.0032'
     '11.0014' '15.0013' '8.9981' '7.0015' '7.0015' '19.0012' '15.0013'
     '16.9979' '15.0013' '7.0015' '12.998' '7.0015' '11.0014' '11.0014'
     '6.0032' '7.0015' '6.0032' '7.0015' '12.998' '7.0015' '6.0032' '11.0014'
     '11.0014' '6.0032' '11.0014' '7.0015' '6.0032' '7.0015' '7.0015' '8.9981'
     '8.9981' '6.0032' '27.9993' '23.9994' '19.9995' '12.998' '11.0014'
     '6.0032' '8.9981' '8.9981' '26.0027' '26.0027' '19.9995' '19.9995'
     '7.0015' '7.0015' '6.0032' '6.0032' '8.9981' '8.9981' '8.9981' '6.0032'
     '11.0014' '16.9979' '27.9993' '11.0014' '11.0014' '12.998' '15.0013'
     '8.9981' '8.9981' '7.0015' '7.0015' '8.9981' '7.0015' '8.9981' '12.998'
     '7.0015' '8.9981' '16.9979' '12.998' '7.0015' '7.0015' '7.0015' '7.0015'
     '12.998' '7.0015' '7.0015' '12.998' '15.0013' '15.0013' '12.998' '12.998'
     '12.998' '12.998' '6.0032' '6.0032' '6.0032' '12.998' '11.0014' '8.9981'
     '6.0032' '7.0015' '6.0032' '6.0032' '7.0015' '6.0032' '11.0014' '11.0014'
     '7.0015' '6.0032' '6.0032' '8.9981' '8.9981' '8.9981' '8.9981' '8.9981'
     '15.0013' '15.0013' '6.0032' '6.0032' '7.0015' '6.0032' '6.0032' '6.0032'
     '16.9979' '6.0032' '6.0032' '6.0032' '6.0032' '12.998' '6.0032' '7.0015'
     '6.0032' '6.0032' '12.998' '12.998' '11.0014' '11.0014' '6.0032'
     '19.9995' '11.0014' '32.9975' '12.998' '12.998' '7.0015' '8.9981'
     '8.9981' '6.0032' '6.0032' '6.0032' '12.998' '11.0014' '7.0015' '8.9981'
     '8.9981' '27.9993' '7.0015' '6.0032' '7.0015' '7.0015' '31.0009'
     '11.0014' '7.0015' '6.0032' '6.0032' '12.998' '12.998' '12.998' '8.9981'
     '7.0015' '7.0015' '15.0013' '6.0032' '7.0015' '7.0015' '7.0015' '7.0015'
     '7.0015' '7.0015' '7.0015' '7.0015' '7.0015' '7.0015' '12.998' '6.0032'
     '6.0032' '12.998' '7.0015' '8.9981' '8.9981' '15.0013' '15.0013' '8.9981'
     '6.0032' '7.0015' '7.0015' '7.0015' '7.0015' '7.0015' '6.0032' '15.0013'
     '11.0014' '7.0015' '7.0015' '11.0014' '7.0015' '15.0013' '16.9979'
     '16.9979' '16.9979' '11.0014' '11.0014' '11.0014' '7.0015' '7.0015'
     '15.0013' '6.0032' '19.9995' '8.9981' '12.998' '6.0032' '12.998' '12.998'
     '7.0015' '11.0014' '11.0014' '7.0015' '7.0015' '11.0014' '19.0012'
     '8.9981' '8.9981' '12.998' '6.0032' '19.0012' '11.0014' '7.0015' '7.0015'
     '7.0015' '7.0015' '7.0015' '8.9981' '19.0012' '6.0032' '7.0015' '11.0014'
     '8.9981' '6.0032' '6.0032' '27.9993' '6.0032' '6.0032' '26.0027'
     '26.0027' '8.9981' '6.0032' '7.0015' '6.0032' '6.0032' '11.0014'
     '11.0014' '7.0015' '6.0032' '6.0032' '11.0014' '12.998' '7.0015'
     '15.0013' '8.9981' '6.0032' '7.0015' '7.0015' '6.0032' '6.0032' '6.0032'
     '6.0032' '6.0032' '6.0032' '8.9981' '8.9981' '6.0032' '8.9981' '6.0032'
     '22.0028' '11.0014' '6.0032' '6.0032' '6.0032' '6.0032' '6.0032' '6.0032'
     '7.0015' '7.0015' '7.0015' '16.9979' '6.0032' '6.0032' '12.998' '12.998'
     '12.998' '8.9981' '6.0032' '15.0013' '11.0014' '11.0014' '6.0032'
     '6.0032' '6.0032' '6.0032' '11.0014' '22.0028' '19.0012' '12.998'
     '12.998' '15.0013' '11.0014' '6.0032' '12.998' '6.0032' '11.0014'
     '11.0014' '6.0032' '7.0015' '6.0032' '7.0015' '12.998' '12.998' '6.0032'
     '6.0032' '6.0032' '6.0032' '19.0012' '7.0015' '12.998' '11.0014' '12.998'
     '6.0032' '12.998' '8.9981' '11.0014' '6.0032' '15.0013' '23.9994'
     '6.0032' '6.0032' '30.0026' '6.0032' '19.9995' '16.9979' '15.0013'
     '15.0013' '15.0013' '11.0014' '27.9993' '7.0015' '7.0015' '7.0015'
     '12.998' '16.9979' '22.0028' '15.0013' '16.9979' '6.0032' '6.0032'
     '6.0032' '12.998' '8.9981' '32.9975' '16.9979' '12.998' '11.0014'
     '11.0014' '12.998' '6.0032' '6.0032' '8.9981' '32.9975' '19.0012'
     '7.0015' '27.9993' '11.0014' '11.0014' '7.0015' '7.0015' '11.0014'
     '16.9979' '16.9979' '7.0015' '11.0014' '19.9995' '11.0014' '6.0032'
     '11.0014' '11.0014' '8.9981' '7.0015' '6.0032' '6.0032' '6.0032'
     '22.0028' '22.0028' '6.0032' '7.0015' '7.0015' '7.0015' '7.0015' '7.0015'
     '6.0032' '6.0032' '8.9981' '11.0014' '11.0014' '11.0014' '7.0015'
     '6.0032' '6.0032' '11.0014' '22.0028' '11.0014' '6.0032' '6.0032'
     '7.0015' '19.9995' '8.9981' '6.0032' '15.0013' '15.0013' '12.998'
     '11.0014' '11.0014' '6.0032' '11.0014' '7.0015' '7.0015' '7.0015'
     '16.9979' '11.0014' '6.0032' '6.0032' '6.0032' '11.0014' '19.9995'
     '11.0014' '8.9981' '8.9981' '8.9981' '8.9981' '8.9981' '8.9981' '8.9981'
     '15.0013' '6.0032' '8.9981' '8.9981' '15.0013' '8.9981' '7.0015'
     '11.0014' '16.9979' '11.0014' '11.0014' '15.0013' '7.0015' '27.9993'
     '12.998' '6.0032' '6.0032' '11.0014' '6.0032' '6.0032' '16.9979'
     '16.9979' '8.9981' '12.998' '7.0015' '11.0014' '8.9981' '8.9981' '6.0032'
     '6.0032' '11.0014' '6.0032' '7.0015' '7.0015' '7.0015' '7.0015' '7.0015'
     '7.0015' '12.998' '19.0012' '6.0032' '6.0032' '6.0032' '8.9981' '11.0014'
     '6.0032' '6.0032' '6.0032' '6.0032' '7.0015' '16.9979' '31.0009'
     '31.0009' '22.0028' '6.0032' '6.0032' '22.0028' '11.0014' '19.0012'
     '11.0014' '6.0032' '11.0014' '8.9981' '11.0014' '11.0014' '6.0032'
     '6.0032' '6.0032' '6.0032' '6.0032' '7.0015' '6.0032' '12.998' '12.998'
     '6.0032' '7.0015' '6.0032' '11.0014' '12.998' '7.0015' '7.0015' '8.9981'
     '6.0032' '7.0015' '7.0015' '7.0015' '7.0015' '6.0032' '7.0015' '8.9981'
     '16.9979' '7.0015' '19.9995' '12.998' '8.9981' '7.0015' '7.0015' '8.9981'
     '7.0015' '6.0032' '6.0032' '6.0032' '6.0032' '6.0032' '16.9979' '8.9981'
     '16.9979' '12.998' '19.9995' '16.9979' '6.0032' '6.0032' '6.0032'
     '12.998' '8.9981' '6.0032' '19.9995' '6.0032' '6.0032' '19.9995' '6.0032'
     '6.0032' '12.998' '8.9981' '12.998' '19.0012' '6.0032' '6.0032' '6.0032'
     '8.9981' '6.0032' '16.9979' '11.0014' '15.0013' '11.0014' '11.0014'
     '8.9981' '11.0014' '11.0014' '11.0014' '11.0014' '6.0032' '11.0014'
     '6.0032' '7.0015' '8.9981' '22.0028' '7.0015' '16.9979' '6.0032'
     '11.0014' '7.0015' '7.0015' '7.0015' '16.9979' '15.0013' '8.9981'
     '6.0032' '6.0032' '6.0032' '11.0014' '6.0032' '8.9981' '8.9981' '11.0014'
     '6.0032' '7.0015' '11.0014' '6.0032' '8.9981' '8.9981' '7.0015' '7.0015'
     '12.998' '7.0015' '6.0032' '6.0032' '15.0013' '6.0032' '16.9979'
     '16.9979' '12.998' '15.0013' '8.9981' '6.0032' '8.9981' '6.0032' '8.9981'
     '6.0032' '6.0032' '6.0032' '6.0032' '6.0032' '11.0014' '11.0014'
     '11.0014' '11.0014' '6.0032' '11.0014' '6.0032' '6.0032' '6.0032'
     '6.0032' '6.0032' '6.0032' '6.0032' '6.0032' '6.0032' '11.0014' '7.0015'
     '8.9981' '7.0015' '7.0015' '7.0015' '7.0015' '6.0032' '6.0032' '6.0032'
     '6.0032' '6.0032' '6.0032' '6.0032' '6.0032' '6.0032' '6.0032' '6.0032'
     '6.0032' '6.0032' '6.0032' '12.998' '6.0032' '6.0032' '6.0032' '6.0032'
     '6.0032' '6.0032' '7.0015' '6.0032' '6.0032' '6.0032' '7.0015' '11.0014'
     '11.0014' '11.0014' '8.9981' '7.0015' '6.0032' '6.0032' '6.0032' '6.0032'
     '6.0032' '6.0032' '6.0032' '11.0014' '6.0032' '6.0032' '6.0032' '6.0032'
     '7.0015' '8.9981' '8.9981' '8.9981' '6.0032' '6.0032' '6.0032' '6.0032'
     '6.0032' '6.0032' '31.0009' '11.0014']
    

    C:\Users\student\Anaconda3\lib\site-packages\ipykernel_launcher.py:21: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    


```python
fig,ax1=plt.subplots()
plt.sca(ax1)
fig.set_size_inches(10,5)
plt.xticks(rotation=30)
sns.countplot(data=tr1,x='windspeed',ax=ax1)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x259df154b88>




![png](output_15_1.png)



```python
fig,ax1=plt.subplots()
plt.sca(ax1)
fig.set_size_inches(10,5)
plt.xticks(rotation=30)
sns.countplot(data=te1,x='windspeed',ax=ax1)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x259df0ea788>




![png](output_16_1.png)



```python
*feature selection
( ?? ) -> count?
연속형(temp,humi,windsp,atemp)
범주형(season...) -> type을 category로
```


```python

tr1['season']=tr1['season'].astype('category')
te1['season']=te1['season'].astype('category')
```


```python
tr1['season'].dtypes
te1['season'].dtypes
```




    CategoricalDtype(categories=[1, 2, 3, 4], ordered=False)




```python
# 범주형으로 한 번에 바꾸기, for문 사용
tr1.columns
feature_names=['season', 'holiday', 'workingday', 'weather', 'temp',
       'atemp','humidity','windspeed','year','hour','dayofweek']
c_f_n=['season', 'holiday', 'workingday', 'weather', 'temp',
       'atemp','humidity','windspeed','year','hour','dayofweek','month']
for v in c_f_n:
    tr1[v]=tr1[v].astype('category')
    te1[v]=te1[v].astype('category')
```


```python
xtr1=tr1[feature_names]
print(xtr1.shape)
xte1=te1[feature_names]
xte1.shape
```

    (10886, 11)
    




    (6493, 11)




```python
ytr1=tr1['count'] #레이블(정답)
ytr1.shape
```




    (10886,)




```python
def rmsle(predicted_value,actual_value):
    #numpy배열로의 변환
    predicted_value=np.array(predicted_value)
    actual_value=np.array(actual_value)
    log_predict=np.log(predicted_value+1)
    log_actual=np.log(actual_value+1)
    diff=log_predict-log_actual
    diff=np.square(diff)
    mean_diff=diff.mean()
    score=np.sqrt(mean_diff)
    return score
from sklearn.metrics import make_scorer
rmsle_scorer=make_scorer(rmsle)
rmsle_scorer
```




    make_scorer(rmsle)




```python
*cross_validation 핸즈온 머신러닝 p127
data: 400개
1 2 3 4 -> 4개의 폴드
    1,2,3: train용으로 씀, 4:test용으로 씀 =>모델 평가(80%)
    1,2,4: train용으로 씀, 3:test용으로 씀 =>모델 평가(70%)    
    1,3,4: train용으로 씀, 2:test용으로 씀 =>모델 평가(80%)
    2,3,4: train용으로 씀, 1:test용으로 씀 =>모델 평가(70%)
```


```python
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
```


```python
kfold=KFold(n_splits=10, shuffle=True, random_state=42)
```


```python
from sklearn.ensemble import RandomForestRegressor
model=RandomForestRegressor(n_estimators=100, n_jobs=-1,random_state=42) 
# <- estimate:model을 몇개 만들 것이냐(나무의갯수) , job: 코어 몇개로 할 것이냐?
#random_state: 
```


```python
%time score=cross_val_score(model, xtr1, ytr1, cv=kfold, scoring=rmsle_scorer)
print(score.mean())
```

    Wall time: 12.8 s
    0.33121957871702457
    


```python
model.fit(xtr1,ytr1)
```




    RandomForestRegressor(bootstrap=True, criterion='mse', max_depth=None,
                          max_features='auto', max_leaf_nodes=None,
                          min_impurity_decrease=0.0, min_impurity_split=None,
                          min_samples_leaf=1, min_samples_split=2,
                          min_weight_fraction_leaf=0.0, n_estimators=100, n_jobs=-1,
                          oob_score=False, random_state=42, verbose=0,
                          warm_start=False)




```python
prediction=model.predict(xte1)
```


```python
prediction   # <- 최종 예측값
```




    array([ 11.19 ,   5.27 ,   4.43 , ..., 100.425,  98.704,  48.58 ])




```python
submission=pd.read_csv("sampleSubmission.csv")
submission['count'] = prediction
```


```python
submission
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>2011-01-20 00:00:00</td>
      <td>11.190</td>
    </tr>
    <tr>
      <td>1</td>
      <td>2011-01-20 01:00:00</td>
      <td>5.270</td>
    </tr>
    <tr>
      <td>2</td>
      <td>2011-01-20 02:00:00</td>
      <td>4.430</td>
    </tr>
    <tr>
      <td>3</td>
      <td>2011-01-20 03:00:00</td>
      <td>3.460</td>
    </tr>
    <tr>
      <td>4</td>
      <td>2011-01-20 04:00:00</td>
      <td>3.330</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>6488</td>
      <td>2012-12-31 19:00:00</td>
      <td>201.670</td>
    </tr>
    <tr>
      <td>6489</td>
      <td>2012-12-31 20:00:00</td>
      <td>160.100</td>
    </tr>
    <tr>
      <td>6490</td>
      <td>2012-12-31 21:00:00</td>
      <td>100.425</td>
    </tr>
    <tr>
      <td>6491</td>
      <td>2012-12-31 22:00:00</td>
      <td>98.704</td>
    </tr>
    <tr>
      <td>6492</td>
      <td>2012-12-31 23:00:00</td>
      <td>48.580</td>
    </tr>
  </tbody>
</table>
<p>6493 rows × 2 columns</p>
</div>




```python
submission.to_csv("sarotto_submission.csv") <-이렇게하면 index가 생겨서 문제임
```


```python
submission.to_csv("sarotto_submission.csv",index=False) 
```


```python

```


```python

```
